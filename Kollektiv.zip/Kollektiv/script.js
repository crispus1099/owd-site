// Açılış ekranı
window.addEventListener('load', () => { setTimeout(()=>{ document.getElementById('splash').style.display='none'; },5000); });

// Menü toggle
const menuToggle = document.getElementById('menuToggle');
const menuContent = document.getElementById('menuContent');
const wolfFang = document.getElementById('wolfFang');
menuToggle.addEventListener('click', () => {
  if(menuContent.style.display==='block') {
    menuContent.style.display='none'; wolfFang.style.opacity='0';
  } else {
    menuContent.style.display='block'; wolfFang.style.opacity='1';
  }
});

// Tema toggle
const themeToggle = document.getElementById('themeToggle');
themeToggle.addEventListener('click', ()=>{ document.body.classList.toggle('dark'); });

// Dil toggle
const langToggle = document.getElementById('langToggle');
langToggle.addEventListener('click', ()=>{
  document.body.style.filter='blur(5px)';
  setTimeout(()=>{ document.body.style.filter='none'; },2000);
});

// Çerezler
document.getElementById('acceptCookies').addEventListener('click', ()=>alert('Çerezler kabul edildi'));
document.getElementById('declineCookies').addEventListener('click', ()=>alert('Özel / Hayır seçildi'));

// Basit AI paneli
const aiInput = document.getElementById('aiInput');
const aiSend = document.getElementById('aiSend');
const aiChat = document.getElementById('aiChat');
aiSend.addEventListener('click', ()=>{
  const msg = aiInput.value;
  if(msg.trim()==='') return;
  const p = document.createElement('p');
  p.textContent = 'Sen: '+msg;
  aiChat.appendChild(p);
  const resp = document.createElement('p');
  resp.textContent = 'Omega AI: Şu anda demo cevap veriyor.';
  aiChat.appendChild(resp);
  aiInput.value='';
  aiChat.scrollTop = aiChat.scrollHeight;
});